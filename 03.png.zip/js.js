var button = document.querySelector('button');

Купить тренара.addEventListener('click', function() {
	alert('Нет')
})